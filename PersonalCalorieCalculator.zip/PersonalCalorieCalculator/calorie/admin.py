from django.contrib import admin
from .models import Calorie  # veya from post.models import Post


class CalorieAdmin(admin.ModelAdmin):
    list_display = ['Gender', 'publishing_date', 'slug']
    list_display_links = ['publishing_date']
    list_filter = ['publishing_date']
    search_fields = ['Gender', 'Age','Weight','Height','calc']
    list_editable = ['Gender']

    class Meta:
        model = Calorie



admin.site.register(Calorie, CalorieAdmin)