from django.db import models
from django.urls import reverse
from django.utils.text import slugify


class Calorie(models.Model):
    #user = models.ForeignKey('auth.User', related_name='posts',on_delete=models.CASCADE)
    Male = 'M'
    FeMale = 'F'
    GENDER_CHOICES = (
        (Male, 'Male'),
        (FeMale, 'Female'),
    )

    Gender = models.CharField(max_length = 6, choices = GENDER_CHOICES,
                              default = Male)
    Age = models.IntegerField()
    Height = models.IntegerField(verbose_name='Height-type in cm')
    Weight = models.IntegerField(verbose_name='Weigh-type in kg')
    publishing_date = models.DateTimeField(verbose_name="Date", auto_now_add=True)
    calc = models.FloatField(null=True)
    slug = models.SlugField(null=True, editable=False, max_length=130)

    class Meta:
        ordering = ['-publishing_date', 'id']

    @property
    def calorie_calc(self):


        if self.Gender == 'M':
            x = 66 + ((13.7)*self.Weight) + (5*self.Height) - ((6.8)*self.Age)
        elif self.Gender == 'F':
            x = 655 + ((9.6)*self.Weight) + ((1.8)*self.Height) - ((4.7)*self.Age)

        return x/1000


    def save(self, *args, **kwargs):

        self.calc = self.calorie_calc
        super(Calorie, self).save(*args, **kwargs)
    #def __str__(self):
        #return self.title

    #def get_absolute_url(self):

        #return "/calorie/{}".format(self.id)

    def get_absolute_url(self):
        return reverse('calorie:detail')
        #return "/calorie/{}".format(self.id)

    #def get_create_url(self):
        #return reverse('post:create', kwargs={'slug': self.slug})

    #def get_update_url(self):
        #return reverse('post:update', kwargs={'slug': self.slug})



    #def get_unique_slug(self):
        #slug = slugify(self.title.replace('ı', 'i'))
        #unique_slug = slug
       # counter = 1
        #while Post.objects.filter(slug=unique_slug).exists():
            #unique_slug = '{}-{}'.format(slug, counter)
            #counter += 1
        #return unique_slug

    #def save(self, *args, **kwargs):
        #self.slug = self.get_unique_slug()
        #return super(Post, self).save(*args, **kwargs)



    #created_date = models.DateTimeField(auto_now_add=True)


