from django.apps import AppConfig


class CalorieConfig(AppConfig):
    name = 'calorie'
