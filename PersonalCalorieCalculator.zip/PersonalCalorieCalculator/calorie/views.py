from django.shortcuts import render, HttpResponse, get_object_or_404, HttpResponseRedirect, redirect, Http404

from calorie.forms import CalorieForm
from .models import Calorie
#from .forms import PostForm, CommentForm
from django.contrib import messages
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger
from django.db.models import Q




def calorie_detail(request):#add slug parameter
    calorie = Calorie.objects.order_by('id').last()
    form = CalorieForm(request.POST or None)
    if form.is_valid():
        comment = form.save(commit=False)
        comment.calorie = calorie
        comment.save()
        return HttpResponseRedirect(calorie.get_absolute_url)

    context = {
        'calorie': calorie,
        'form': form
    }
    return render(request, "calorie/detail.html", context)


def calorie_create(request):


    form = CalorieForm(request.POST or None)

    if request.method == 'POST' and form.is_valid():
        calorie = form.save(commit=False)
        calorie.user = request.user
        calorie.save()
        messages.success(request, "You have successfully created it.", extra_tags='mesaj-basarili')
        return HttpResponseRedirect(calorie.get_absolute_url())



    context = {
        'form': form
    }

    return render(request, "calorie/form.html", context)




