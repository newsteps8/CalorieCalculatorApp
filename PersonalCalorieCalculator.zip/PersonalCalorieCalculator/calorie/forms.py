from django import forms
from .models import Calorie
#from captcha.fields import ReCaptchaField


class CalorieForm(forms.ModelForm):
    #captcha = ReCaptchaField()

    class Meta:
        model = Calorie
        fields = [
            'Gender',
            'Age',
            'Height',
            'Weight',

        ]